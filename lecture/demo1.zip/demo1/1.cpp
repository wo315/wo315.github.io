#include <fvCFD.H>

int main() {
    List<scalar> lst{1, 2, 3, 4, 5, 6};

    forAll(lst, i)
        Info << lst[i] << " ";
    Info << " " << nl;

    forAllReverse(lst, i)
        Info << lst[i] << " ";
    Info << " " << nl;

    forAllIters(lst, it)
        Info << *it << " ";
    Info << " " << nl;

    forAllConstIters(lst, it)
        Info << *it << " ";
    Info << " " << nl;

    forAllReverseIters(lst, it)
        Info << *it << " ";
    Info << " " << nl;

    forAllConstIters(lst, it)
        Info << *it << " ";
    Info << " " << nl;

    return 0;
}